# Publication checklist

## Tableau Public

1. Open the packaged workbook and select 01 Executive Health.
2. Restore defaults: As of 14 September 2026, Days 30, Source All, Scope All streams.
3. Hide supporting worksheets from the tab bar while keeping the four dashboard tabs visible, if desired.
4. Select Server > Tableau Public > Save to Tableau Public. Sign in to your own account.
5. Use the title: Enterprise Data Cloud Operations | Tableau Portfolio.
6. If Tableau requests extracts, create them for the packaged CSV sources and retry saving.
7. Check all four dashboards in the published browser view and copy the public URL into README.md.

Description to paste:

Synthetic Salesforce Data Cloud-style operations monitoring across 83 streams (20 critical), 30 segments and 45 activations. Four Tableau dashboards explore stream health, refresh SLA compliance, segment readiness, activation delivery and execution failures over 180 days. Built with synthetic CSV data; no live Salesforce or Snowflake connection. Portfolio demonstration, not production customer data.

## GitHub

Suggested public repository name: data-cloud-operations-tableau

Description: Tableau portfolio: synthetic Data Cloud operations monitoring, SLA analysis, critical streams, segments and activations.

Upload the contents of this project directory, not the enclosing ZIP. Preserve the work/, outputs/ and docs/ folders. Add the Tableau Public URL as the repository website and replace the pending link in README.md. Suggested topics: tableau, tableau-public, business-intelligence, data-visualization, data-quality, synthetic-data, portfolio.

After publication, pin the repository and Tableau visualization on the respective profiles. Export clean dashboard images from Tableau for a later screenshots section; authoring-UI screenshots are not bundled in this release.

Official references:
- https://help.tableau.com/current/pro/desktop/en-us/publish_workbooks_tableaupublic.htm
- https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository
