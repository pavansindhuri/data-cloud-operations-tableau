# Enterprise Salesforce Data Cloud Monitoring & Operations — Step 2

## Provenance and scope
Entirely synthetic portfolio data; seed 20260915. No company/client records, customer identifiers, credentials, hosts or contact details are used. These are custom monitoring tables, not Salesforce API payloads or claims about native Salesforce status semantics.

Period: 2026-03-19 through 2026-09-14 inclusive, 180 complete days. UTC timestamps use YYYY-MM-DD HH:MM:SS. CSV is UTF-8, comma-delimited, with headers; empty fields mean NULL, never zero. Fractions are 0..1 and should be formatted as percentages in Tableau.

83 streams, exactly 20 critical, 30 segments, 45 activations. All are active for the full period. Critical streams run every 6 hours, the next 30 streams every 12 hours, the last 33 once daily. Scheduled starts begin at 01:00 UTC. Thus 173 refresh obligations are due each day. Critical completion SLA is 120 minutes; other completion SLAs are 180 minutes. These are fictional policy choices.

## Start here in Tableau Public Edition
1. Extract the ZIP into a permanent project folder.
2. Open TABLEAU_STREAM_DAILY.csv with the Text File connection. Keep the other files for later steps.
3. Check Date is a Date; refresh/start/end/snapshot fields are Date & Time; IDs are strings; counts are whole numbers; ratios and durations are decimal numbers.
4. At the latest date, COUNTD(Data_Stream_ID) must be 83 and the count with Critical_Flag = 1 must be 20.
5. Stop at dataset review. Dashboard-building and SQL instructions belong to subsequent steps.

Use TABLEAU_SEGMENT_DAILY.csv and TABLEAU_ACTIVATION_DAILY.csv as separate analytical sources later. They include descriptive attributes to work without Snowflake. The normalized DIM/FACT/BRIDGE files support the later Snowflake exercise.

## Metric rules
- TABLEAU_* files are derived conveniences. Do not union them with raw FACT files or count both.
- Stream daily volume is the sum of attempts completed that day. All generated stream attempts finish before 23:00 UTC. Segment runs start at 23:00; activation runs at 23:30. Daily snapshots are 23:59:59. No future observation is used for downstream processing.
- Failed stream attempts are atomic infrastructure failures: zero accepted and zero rejected records. A failed run with zero rejected records is intentional. Successful runs may have rejected records. This is why run success and record quality are separate KPIs.
- A retry follows a failed attempt and shares its obligation. At most one successful commit per obligation; volume never commits twice. Only first attempts can fail in this simulation. This is a simplification, not a claim about production retry behavior.
- Late success remains an SLA breach for that obligation. Daily SLA compliance is SUM(Daily_Obligations_Met)/SUM(Daily_Obligations_Due), never an average of stream percentages.
- Snapshot SLA_Status refers only to the latest obligation. Daily_SLA_Breach_Count includes earlier breaches even if later recovered. Health reflects the latest obligation/run, rather than permanently penalizing a recovered stream for all earlier failures.
- Warning means latest-run rejection ratio >1%, latest-run duration >50 minutes, or successful-refresh age greater than refresh interval, provided no Failed condition applies.
- Snapshot Last_Refresh_Time and duration refer to the latest observed attempt. When latest scheduled run is missing, Status is Not Started, health is Failed, and older observation fields carry forward.
- Processing success = Success attempts / (Success + Failed attempts). Missing attempts affect SLA, not the run denominator. There are no in-progress runs in these end-of-day snapshots.
- Use selected Snapshot_Time for freshness. NOW() would incorrectly age this fixed historical demo.
- Initial last success is a synthetic baseline four hours before the first reporting day. This is explicitly stored in DIM_DATA_STREAM and is not a hidden run.
- Segment population is last successful size, with Population_As_Of; failed segments retain stale populations. Do not sum populations over time. Segments may overlap.
- Segment runs fail when any required upstream stream has Failed health, or occasionally from their own evaluation error. Blocking_Data_Stream_ID shows one offending dependency. This describes the generator's mechanism, not inferred real-world causation.
- Activations depend on the same day's segment execution. A failed segment blocks delivery (zero attempted). Independent destination failures reject all attempted delivery records. Successful activation deliveries can have minor rejections. Delivered records never exceed the parent segment population.
- Source and owner labels are fictional generic categories. SYNTHETIC_INCIDENTS documents deliberately injected episodes; random incidental errors have blank Incident_ID.
- No unique person-level data is present. Records processed, segment population and activation records measure different things and must not be added together.

## Modeling guidance
DIM_DATA_STREAM to stream facts: one-to-many on Data_Stream_ID. DIM_SEGMENT and DIM_ACTIVATION to their facts: one-to-many. DIM_DATE to dated facts: one-to-many. Run to obligation: many-to-one; obligation to Successful_Run_ID is optional and at most one.
Bridge tables support dependency navigation, not physical joins for summing volumes. Joining multiple facts or bridge relationships can multiply rows. DAILY_OPERATIONS_SUMMARY is a separately aggregated reconciliation source; do not physically join its totals onto detailed facts and sum them.

## File inventory
- DIM_DATA_STREAM.csv — 83 rows. One row per data stream; all active for the complete reporting period.
- DIM_DATE.csv — 180 rows. One row per calendar date.
- DIM_SEGMENT.csv — 30 rows. One row per segment.
- DIM_ACTIVATION.csv — 45 rows. One row per activation.
- BRIDGE_STREAM_SEGMENT.csv — 88 rows. One unique stream-to-segment dependency; all dependencies required.
- BRIDGE_SEGMENT_ACTIVATION.csv — 45 rows. One segment-to-activation dependency; each activation uses one segment in this simulation.
- SYNTHETIC_INCIDENTS.csv — 5 rows. One deliberately injected synthetic scenario; unrelated random errors have no incident ID.
- FACT_STREAM_RUN.csv — 31,475 rows. One row per processing attempt; failed attempts are atomic failures with zero records committed.
- FACT_REFRESH_OBLIGATION.csv — 31,140 rows. One row per scheduled refresh; retries share an obligation.
- FACT_STREAM_DAILY_SNAPSHOT.csv — 14,940 rows. One stream per day at 23:59:59 UTC; volume and run measures are daily totals, status is latest state.
- FACT_SEGMENT_RUN.csv — 5,400 rows. One segment execution per day; population is last successful stock and must not be summed over time.
- FACT_ACTIVATION_RUN.csv — 8,100 rows. One activation execution per day; delivered volume is not distinct people across activations.
- TABLEAU_STREAM_DAILY.csv — 14,940 rows. One stream per day; ready-to-use snapshot enriched with stream attributes.
- TABLEAU_SEGMENT_DAILY.csv — 5,400 rows. One segment per day; ready-to-use segment run enriched with segment attributes.
- TABLEAU_ACTIVATION_DAILY.csv — 8,100 rows. One activation per day; ready-to-use activation run enriched with attributes.
- DAILY_OPERATIONS_SUMMARY.csv — 180 rows. One row per day; pre-aggregated reconciliation totals, not a table to join physically to detailed facts.
- DATA_DICTIONARY.csv — 203 rows. One row per column in the 16 data tables.
