# Dataset validation

Validated saved CSV files. All checks below passed. This verifies generated-data consistency, not Tableau application rendering or publishing.

- DIM_DATE unique grain
- DIM_DATA_STREAM unique grain
- DIM_SEGMENT unique grain
- DIM_ACTIVATION unique grain
- FACT_STREAM_RUN unique grain
- FACT_REFRESH_OBLIGATION unique grain
- FACT_STREAM_DAILY_SNAPSHOT unique grain
- FACT_SEGMENT_RUN unique grain
- FACT_ACTIVATION_RUN unique grain
- BRIDGE_STREAM_SEGMENT unique grain
- BRIDGE_SEGMENT_ACTIVATION unique grain
- TABLEAU_STREAM_DAILY unique grain
- TABLEAU_SEGMENT_DAILY unique grain
- TABLEAU_ACTIVATION_DAILY unique grain
- DAILY_OPERATIONS_SUMMARY unique grain
- SYNTHETIC_INCIDENTS unique grain
- DATA_DICTIONARY unique grain
- CSV row counts and SHA256 match manifest
- 83 streams and exactly 20 critical
- 180 dates, 30 segments and 45 activations
- Foreign keys resolve
- All timestamps ordered and downstream stream cutoff respected
- Run duration matches timestamps
- Nonnegative record components reconcile
- Record ratios correct including zero denominator
- At most one successful commit per obligation
- Retries follow failed first attempt
- SLA evaluated from successful completion before deadline
- Daily metrics, current health, freshness and successful-refresh lineage reconcile
- Activation lineage, timing, population limits and blocked delivery reconcile
- Segment blocker references and population timestamps valid
- TABLEAU_STREAM_DAILY derived values match normalized sources
- TABLEAU_SEGMENT_DAILY derived values match normalized sources
- TABLEAU_ACTIVATION_DAILY derived values match normalized sources
- Executive summary balances on all 180 dates
- Missing runs, retries, late successes and partial rejects are present
- Daily entity coverage complete

## Latest snapshot: 2026-09-14

- Date: 2026-09-14
- Total_Streams: 83
- Critical_Streams: 20
- Healthy_Streams: 70
- Warning_Streams: 6
- Failed_Streams: 7
- Unknown_Streams: 0
- Records_Processed: 8143807
- Records_Failed: 35331
- Successful_Runs: 165
- Failed_Runs: 11
- Obligations_Due: 173
- Obligations_Met: 154
- SLA_Breaches: 19
- Segment_Runs: 30
- Successful_Segment_Runs: 20
- Activation_Runs: 45
- Successful_Activation_Runs: 31
- Activation_Records: 3109988
