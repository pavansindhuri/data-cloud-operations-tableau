import csv, json, random, math, hashlib, zipfile
from pathlib import Path
from datetime import datetime, timedelta
from collections import Counter, defaultdict

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'outputs' / 'data_cloud_step2'
OUT.mkdir(parents=True, exist_ok=True)
rng = random.Random(20260915)
END = datetime(2026,9,14)
START = END - timedelta(days=179)
days = [START + timedelta(days=i) for i in range(180)]
fmt = lambda x: x.strftime('%Y-%m-%d %H:%M:%S') if x else None
date = lambda x: x.strftime('%Y-%m-%d')
tables = {}
grains = {}
def table(name, rows, grain):
    assert rows, name
    tables[name] = rows
    grains[name] = grain

sources = ['CRM','Commerce','Service','Loyalty','Web Events','Partner Files']
domains = ['Customer','Sales','Service','Marketing','Commerce','Customer']
teams = ['Customer Data Support','Commerce Data Support','Service Data Support','Audience Operations','Digital Data Support','Integration Support']
entities = ['Profiles','Transactions','Preferences','Interactions','Subscriptions','Products','Orders','Consent','Memberships','Cases','Sessions','Contacts','Addresses','Engagements']
streams=[]
for i in range(1,84):
    src=(i-1)%6
    streams.append(dict(Data_Stream_ID=f'DS{i:03}',Data_Stream_Name=f'{sources[src]} {entities[(i-1)//6]}',Source_System=sources[src],Business_Domain=domains[src],Critical_Flag=int(i<=20),Priority='P1' if i<=8 else 'P2' if i<=20 else 'P3' if i<=55 else 'P4',Owner_Support_Team=teams[src],Refresh_Interval_Hours=6 if i<=20 else 12 if i<=50 else 24,SLA_Allowance_Minutes=120 if i<=20 else 180,Failure_Warning_Threshold=0.01,Duration_Warning_Minutes=50,Baseline_Records=8000+i*1700,Active_From=date(START),Initial_Last_Successful_Refresh=fmt(START-timedelta(hours=4)),Synthetic_Flag=1))
table('DIM_DATA_STREAM',streams,'One row per data stream; all active for the complete reporting period')
table('DIM_DATE',[dict(Date=date(d),Year=d.year,Month=d.month,Month_Name=d.strftime('%B'),Week_Start=date(d-timedelta(days=d.weekday())),Day_Name=d.strftime('%A'),Is_Weekend=int(d.weekday()>4)) for d in days],'One row per calendar date')
segments=[dict(Segment_ID=f'SEG{i:03}',Segment_Name=f'{["Loyalty Growth","Recent Purchasers","Service Recovery","Engaged Visitors","Repeat Customers","Reactivation"][ (i-1)%6]} Audience {i:02}',Business_Domain='Marketing',Owner_Support_Team='Audience Operations',Synthetic_Flag=1) for i in range(1,31)]
activations=[dict(Activation_ID=f'ACT{i:03}',Activation_Name=f'{["Retention","Welcome","Cross Sell","Service Follow Up","Win Back"][(i-1)%5]} Delivery {i:02}',Activation_Destination=['Email Platform','Advertising Platform','CRM Campaign','Cloud Storage','Personalization Platform'][(i-1)%5],Owner_Support_Team='Activation Support',Synthetic_Flag=1) for i in range(1,46)]
table('DIM_SEGMENT',segments,'One row per segment')
table('DIM_ACTIVATION',activations,'One row per activation')
bs=[]
for i,s in enumerate(segments):
    deps=sorted({i%20,(i*3+21)%83,(i*7+40)%83})
    bs += [dict(Data_Stream_ID=streams[j]['Data_Stream_ID'],Segment_ID=s['Segment_ID']) for j in deps]
ba=[dict(Segment_ID=segments[i%30]['Segment_ID'],Activation_ID=a['Activation_ID']) for i,a in enumerate(activations)]
table('BRIDGE_STREAM_SEGMENT',bs,'One unique stream-to-segment dependency; all dependencies required')
table('BRIDGE_SEGMENT_ACTIVATION',ba,'One segment-to-activation dependency; each activation uses one segment in this simulation')
incidents=[dict(Incident_ID='INC001',Start_Date=date(days[42]),End_Date=date(days[44]),Scope='CRM',Scenario='Authentication outage',Error_Type='Authentication Error',Forced_Mode='Failed'),dict(Incident_ID='INC002',Start_Date=date(days[86]),End_Date=date(days[89]),Scope='Commerce',Scenario='Source schema change',Error_Type='Schema Mismatch',Forced_Mode='Failed'),dict(Incident_ID='INC003',Start_Date=date(days[127]),End_Date=date(days[130]),Scope='Partner Files',Scenario='Late partner delivery',Error_Type='Source Delay',Forced_Mode='Late'),dict(Incident_ID='INC004',Start_Date=date(days[177]),End_Date=date(days[179]),Scope='DS003',Scenario='Critical stream authentication outage',Error_Type='Authentication Error',Forced_Mode='Failed'),dict(Incident_ID='INC005',Start_Date=date(days[179]),End_Date=date(days[179]),Scope='DS007',Scenario='Critical stream partial record rejection',Error_Type='Record Validation',Forced_Mode='Partial')]
table('SYNTHETIC_INCIDENTS',incidents,'One deliberately injected synthetic scenario; unrelated random errors have no incident ID')
runs=[]; obligations=[]; snaps=[]
last_success={s['Data_Stream_ID']:datetime.fromisoformat(s['Initial_Last_Successful_Refresh']) for s in streams}
latest={}; daily_state={}
for di,d in enumerate(days):
    for si,s in enumerate(streams):
        sid=s['Data_Stream_ID']; dayruns=[]; dayobs=[]
        for slot,h in enumerate(range(1,24,s['Refresh_Interval_Hours'])):
            scheduled=d+timedelta(hours=h); deadline=scheduled+timedelta(minutes=s['SLA_Allowance_Minutes'])
            oid=f'OB{di:03}{si+1:03}{slot+1}'
            incident=next((x for x in incidents if x['Start_Date']<=date(d)<=x['End_Date'] and x['Scope'] in (sid,s['Source_System'])),None)
            u=rng.random()
            mode=incident['Forced_Mode'] if incident else ('Missed' if u<.008 else 'Failed' if u<.038 else 'Late' if u<.075 else 'Partial' if u<.13 else 'Normal')
            attempts=[]
            if mode!='Missed':
                retry=mode=='Failed' and incident is None and rng.random()<.65
                for attempt in range(1,3 if retry else 2):
                    failed=mode=='Failed' and attempt==1
                    lag=(s['SLA_Allowance_Minutes']+10 if mode=='Late' else rng.randint(0,12)) if attempt==1 else 65
                    start=scheduled+timedelta(minutes=lag)
                    duration=rng.randint(8,38) if failed else rng.randint(12,48)
                    if mode=='Partial': duration=rng.randint(40,65)
                    finish=start+timedelta(minutes=duration)
                    volume=int(s['Baseline_Records']*(1+di*.0015)*(1.0 if d.weekday()<5 else .78)*rng.uniform(.8,1.2)/(24/s['Refresh_Interval_Hours']))
                    rejected=0 if failed else int(volume*(rng.uniform(.02,.075) if mode=='Partial' else rng.uniform(0,.003)))
                    accepted=0 if failed else volume-rejected
                    err=(incident['Error_Type'] if incident else rng.choice(['Authentication Error','Schema Mismatch','Connection Timeout','Processing Error'])) if failed else 'Record Validation' if mode=='Partial' else 'Source Delay' if mode=='Late' else 'None'
                    run=dict(Run_ID=f'RUN{len(runs)+1:07}',Obligation_ID=oid,Date=date(d),Data_Stream_ID=sid,Attempt_Number=attempt,Scheduled_Start_Time=fmt(scheduled),Start_Time=fmt(start),End_Time=fmt(finish),Status='Failed' if failed else 'Success',Refresh_Duration_Minutes=duration,Records_Processed=accepted,Records_Failed=rejected,Records_Attempted=accepted+rejected,Failure_Percentage=round(rejected/(accepted+rejected),8) if accepted+rejected else None,Error_Type=err,Incident_ID=incident['Incident_ID'] if incident else None)
                    runs.append(run); attempts.append(run); dayruns.append(run); latest[sid]=run
                    if not failed: last_success[sid]=finish
            success=next((r for r in attempts if r['Status']=='Success'),None)
            outcome='Met' if success and datetime.fromisoformat(success['End_Time'])<=deadline else 'Breached'
            ob=dict(Obligation_ID=oid,Date=date(d),Data_Stream_ID=sid,Scheduled_Start_Time=fmt(scheduled),Expected_Refresh_Time=fmt(deadline),Successful_Run_ID=success['Run_ID'] if success else None,Successful_Completion_Time=success['End_Time'] if success else None,SLA_Status=outcome,Breach_Reason='None' if outcome=='Met' else 'Late Completion' if success else 'No Run Started' if not attempts else 'No Successful Completion',Incident_ID=incident['Incident_ID'] if incident else None)
            obligations.append(ob); dayobs.append(ob)
        asof=d+timedelta(hours=23,minutes=59,seconds=59)
        lr=latest.get(sid); mostrecent=dayobs[-1]
        # Last observation carries forward, but a missed latest obligation remains visible.
        status=lr['Status'] if lr else 'Unknown'
        age=(asof-last_success[sid]).total_seconds()/3600
        latest_missing=not any(r['Obligation_ID']==mostrecent['Obligation_ID'] for r in dayruns)
        health='Failed' if mostrecent['SLA_Status']=='Breached' or status=='Failed' else 'Warning' if (lr and ((lr['Failure_Percentage'] or 0)>.01 or lr['Refresh_Duration_Minutes']>50)) or age>s['Refresh_Interval_Hours'] else 'Healthy' if lr else 'Unknown'
        processed=sum(r['Records_Processed'] for r in dayruns); rejected=sum(r['Records_Failed'] for r in dayruns)
        snap=dict(Date=date(d),Data_Stream_ID=sid,Snapshot_Time=fmt(asof),Latest_Run_ID=lr['Run_ID'] if lr else None,Status='Not Started' if latest_missing else status,Stream_Health=health,Last_Refresh_Time=lr['End_Time'] if lr else None,Last_Successful_Refresh=fmt(last_success[sid]),Expected_Refresh_Time=mostrecent['Expected_Refresh_Time'],Hours_Since_Last_Refresh=round(age,6),Refresh_Duration_Minutes=lr['Refresh_Duration_Minutes'] if lr else None,Latest_Run_Failure_Percentage=lr['Failure_Percentage'] if lr else None,SLA_Status=mostrecent['SLA_Status'],Records_Processed=processed,Records_Failed=rejected,Failure_Percentage=round(rejected/(processed+rejected),8) if processed+rejected else None,Daily_Run_Count=len(dayruns),Daily_Successful_Runs=sum(r['Status']=='Success' for r in dayruns),Daily_Failed_Runs=sum(r['Status']=='Failed' for r in dayruns),Daily_Obligations_Due=len(dayobs),Daily_Obligations_Met=sum(o['SLA_Status']=='Met' for o in dayobs),Daily_SLA_Breach_Count=sum(o['SLA_Status']=='Breached' for o in dayobs),Error_Type='Schedule Missed' if latest_missing else lr['Error_Type'] if lr else 'No Observation',Incident_ID=mostrecent['Incident_ID'])
        snaps.append(snap); daily_state[(date(d),sid)]=snap
table('FACT_STREAM_RUN',runs,'One row per processing attempt; failed attempts are atomic failures with zero records committed')
table('FACT_REFRESH_OBLIGATION',obligations,'One row per scheduled refresh; retries share an obligation')
table('FACT_STREAM_DAILY_SNAPSHOT',snaps,'One stream per day at 23:59:59 UTC; volume and run measures are daily totals, status is latest state')

deps=defaultdict(list)
for b in bs: deps[b['Segment_ID']].append(b['Data_Stream_ID'])
sruns=[]; aruns=[]; seglookup={}; pop={s['Segment_ID']:12000+i*8500 for i,s in enumerate(segments)}; poptime={s['Segment_ID']:fmt(START-timedelta(hours=1)) for s in segments}
for di,d in enumerate(days):
    for i,s in enumerate(segments):
        sid=s['Segment_ID']; upstream=next((k for k in deps[sid] if daily_state[(date(d),k)]['Stream_Health']=='Failed'),None)
        status='Failed' if upstream or rng.random()<.025 else 'Success'
        end=d+timedelta(hours=23,minutes=rng.randint(8,20))
        if status=='Success': pop[sid]=max(100,int((12000+i*8500)*(1+di*.001)*rng.uniform(.96,1.04))); poptime[sid]=fmt(end)
        r=dict(Segment_Run_ID=f'SRUN{len(sruns)+1:06}',Date=date(d),Segment_ID=sid,Start_Time=fmt(d+timedelta(hours=23)),End_Time=fmt(end),Segment_Status=status,Segment_Population=pop[sid],Population_As_Of=poptime[sid],Error_Type='Upstream Dependency' if upstream else 'Segment Evaluation Error' if status=='Failed' else 'None',Blocking_Data_Stream_ID=upstream)
        sruns.append(r); seglookup[(date(d),sid)]=r
    for i,a in enumerate(activations):
        sid=ba[i]['Segment_ID']; parent=seglookup[(date(d),sid)]
        blocked=parent['Segment_Status']=='Failed'; failed=blocked or rng.random()<.035
        attempted=0 if blocked else int(parent['Segment_Population']*rng.uniform(.55,.95))
        rejected=attempted if failed else int(attempted*rng.uniform(0,.004))
        aruns.append(dict(Activation_Run_ID=f'ARUN{len(aruns)+1:06}',Date=date(d),Activation_ID=a['Activation_ID'],Segment_ID=sid,Segment_Run_ID=parent['Segment_Run_ID'],Start_Time=fmt(d+timedelta(hours=23,minutes=30)),End_Time=fmt(d+timedelta(hours=23,minutes=rng.randint(36,48))),Activation_Status='Failed' if failed else 'Success',Activation_Records=attempted-rejected,Activation_Records_Failed=rejected,Activation_Records_Attempted=attempted,Error_Type='Upstream Dependency' if blocked else 'Destination Timeout' if failed else 'None'))
table('FACT_SEGMENT_RUN',sruns,'One segment execution per day; population is last successful stock and must not be summed over time')
table('FACT_ACTIVATION_RUN',aruns,'One activation execution per day; delivered volume is not distinct people across activations')
sm={s['Data_Stream_ID']:s for s in streams}; segm={s['Segment_ID']:s for s in segments}; am={a['Activation_ID']:a for a in activations}
table('TABLEAU_STREAM_DAILY',[{**sm[r['Data_Stream_ID']],**r} for r in snaps],'One stream per day; ready-to-use snapshot enriched with stream attributes')
table('TABLEAU_SEGMENT_DAILY',[{**segm[r['Segment_ID']],**r} for r in sruns],'One segment per day; ready-to-use segment run enriched with segment attributes')
table('TABLEAU_ACTIVATION_DAILY',[{**am[r['Activation_ID']],**r, 'Segment_Name':segm[r['Segment_ID']]['Segment_Name']} for r in aruns],'One activation per day; ready-to-use activation run enriched with attributes')
summary=[]
for d in days:
    ds=date(d); rows=[daily_state[(ds,s['Data_Stream_ID'])] for s in streams]
    sg=[r for r in sruns if r['Date']==ds]; ac=[r for r in aruns if r['Date']==ds]
    summary.append(dict(Date=ds,Total_Streams=len(rows),Critical_Streams=20,Healthy_Streams=sum(r['Stream_Health']=='Healthy' for r in rows),Warning_Streams=sum(r['Stream_Health']=='Warning' for r in rows),Failed_Streams=sum(r['Stream_Health']=='Failed' for r in rows),Unknown_Streams=sum(r['Stream_Health']=='Unknown' for r in rows),Records_Processed=sum(r['Records_Processed'] for r in rows),Records_Failed=sum(r['Records_Failed'] for r in rows),Successful_Runs=sum(r['Daily_Successful_Runs'] for r in rows),Failed_Runs=sum(r['Daily_Failed_Runs'] for r in rows),Obligations_Due=sum(r['Daily_Obligations_Due'] for r in rows),Obligations_Met=sum(r['Daily_Obligations_Met'] for r in rows),SLA_Breaches=sum(r['Daily_SLA_Breach_Count'] for r in rows),Segment_Runs=len(sg),Successful_Segment_Runs=sum(r['Segment_Status']=='Success' for r in sg),Activation_Runs=len(ac),Successful_Activation_Runs=sum(r['Activation_Status']=='Success' for r in ac),Activation_Records=sum(r['Activation_Records'] for r in ac)))
table('DAILY_OPERATIONS_SUMMARY',summary,'One row per day; pre-aggregated reconciliation totals, not a table to join physically to detailed facts')

# Field-level documentation, with specific overrides for measures that can be misread.
definitions={
'Date':'Reporting date in UTC (YYYY-MM-DD).', 'Critical_Flag':'1 for business-critical, 0 otherwise; constant for this simulation.',
'Failure_Percentage':'Ratio 0..1 of rejected / (accepted + rejected). Blank if denominator is zero. Daily aggregate in snapshots; per attempt in runs.',
'Latest_Run_Failure_Percentage':'Rejected / attempted for latest run; used for current health, not the daily aggregate.',
'Records_Processed':'Accepted records. Add across dates/runs, but not across raw facts and their derived daily tables. Not unique customers.',
'Records_Failed':'Rejected record count. An atomic infrastructure failure has zero attempted records and still counts as a failed run.',
'Records_Attempted':'Records_Processed + Records_Failed. Retries commit only once under this synthetic atomic-failure model.',
'Stream_Health':'Failed if latest obligation breached or latest run failed; otherwise Warning if latest rejection ratio >1%, duration >50 minutes, or freshness age > interval; otherwise Healthy; Unknown if no run.',
'Status':'Run status Success/Failed. Snapshot status describes latest obligation and can be Not Started while last-refresh fields retain older observations.',
'SLA_Status':'Met/Breached for one obligation; snapshot uses latest obligation, not all obligations for the day.',
'Expected_Refresh_Time':'Scheduled start plus stream SLA allowance; completion deadline, not start time.',
'Last_Refresh_Time':'Completion of latest observed attempt, regardless of success; may carry from an earlier date when no attempt exists.',
'Last_Successful_Refresh':'Latest successful completion as of snapshot; initial baseline is synthetic and stored in DIM_DATA_STREAM.',
'Refresh_Duration_Minutes':'Attempt elapsed minutes; in snapshots duration belongs to latest observed run, including failed runs. Filter success for success-only average.',
'Segment_Population':'Last successful segment size, carried forward on failure. A stock: do not sum across dates or label summed overlapping segments unique customers.',
'Population_As_Of':'Timestamp of the successful population observation; initial synthetic baseline if no observed success yet.',
'Activation_Records':'Records delivered successfully; not unique individuals across activations.',
'Blocking_Data_Stream_ID':'One failing required upstream stream selected in deterministic dependency order; additional failures may exist.',
'Incident_ID':'Injected scenario ID; blank for normal processing and incidental random issues.',
'Daily_SLA_Breach_Count':'Count of obligations due this day that were not completed successfully by deadline, even if later recovered.',
'Hours_Since_Last_Refresh':'Hours since last SUCCESSFUL refresh at snapshot time; does not use the current wall clock.',
'Initial_Last_Successful_Refresh':'Synthetic prior-day seed used until the first successful run in the reporting window.',
'Failure_Warning_Threshold':'Synthetic health threshold as ratio 0..1, not an official Salesforce default.',
'Duration_Warning_Minutes':'Synthetic latest-run duration threshold, not an official Salesforce default.',
'Daily_Obligations_Met':'Due obligations successfully completed by their deadline; numerator of SLA compliance.',
'Synthetic_Flag':'Always 1. All records, names and events are generated, not exported from a real organization.'}
dictionary=[]
for name,rows in tables.items():
    for key in rows[0]:
        vals=[r[key] for r in rows if r[key] is not None]
        v=vals[0] if vals else ''
        dtype='INTEGER' if isinstance(v,int) else 'DECIMAL' if isinstance(v,float) else 'TIMESTAMP_NTZ' if isinstance(v,str) and len(v)==19 and v[4]=='-' and v[10]==' ' else 'DATE' if isinstance(v,str) and len(v)==10 and v[4]=='-' and v[7]=='-' else 'TEXT'
        desc=definitions.get(key, key.replace('_',' ') + (': stable synthetic identifier.' if key.endswith('_ID') else ': generated operational attribute or count; see table grain and README.'))
        dictionary.append(dict(Table_Name=name,Column_Name=key,Recommended_Type=dtype,Nullable=int(any(r[key] is None for r in rows)),Definition=desc,Table_Grain=grains[name]))
table('DATA_DICTIONARY',dictionary,'One row per column in the 16 data tables')

# In-memory integrity assertions; saved CSV checks are performed independently below.
assert len(streams)==83 and sum(s['Critical_Flag'] for s in streams)==20
assert len(snaps)==83*180 and len(sruns)==30*180 and len(aruns)==45*180
assert all(datetime.fromisoformat(r['End_Time'])>=datetime.fromisoformat(r['Start_Time']) for r in runs+sruns+aruns)
assert all(datetime.fromisoformat(r['End_Time']) < datetime.fromisoformat(r['Date'])+timedelta(hours=23) for r in runs)
assert all(r['Activation_Records_Attempted']<=seglookup[(r['Date'],r['Segment_ID'])]['Segment_Population'] for r in aruns)
for name,rows in tables.items():
    path=OUT/f'{name}.csv'
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

readme=f'''# Enterprise Salesforce Data Cloud Monitoring & Operations — Step 2

## Provenance and scope
Entirely synthetic portfolio data; seed 20260915. No company/client records, customer identifiers, credentials, hosts or contact details are used. These are custom monitoring tables, not Salesforce API payloads or claims about native Salesforce status semantics.

Period: {date(START)} through {date(END)} inclusive, 180 complete days. UTC timestamps use YYYY-MM-DD HH:MM:SS. CSV is UTF-8, comma-delimited, with headers; empty fields mean NULL, never zero. Fractions are 0..1 and should be formatted as percentages in Tableau.

83 streams, exactly 20 critical, 30 segments, 45 activations. All are active for the full period. Critical streams run every 6 hours, the next 30 streams every 12 hours, the last 33 once daily. Scheduled starts begin at 01:00 UTC. Thus 173 refresh obligations are due each day. Critical completion SLA is 120 minutes; other completion SLAs are 180 minutes. These are fictional policy choices.

## Start here in Tableau Public Edition
1. Extract the ZIP into a permanent project folder.
2. Open TABLEAU_STREAM_DAILY.csv with the Text File connection. Keep the other files for later steps.
3. Check Date is a Date; refresh/start/end/snapshot fields are Date & Time; IDs are strings; counts are whole numbers; ratios and durations are decimal numbers.
4. At the latest date, COUNTD(Data_Stream_ID) must be 83 and the count with Critical_Flag = 1 must be 20.
5. Stop at dataset review. Dashboard-building and SQL instructions belong to subsequent steps.

Use TABLEAU_SEGMENT_DAILY.csv and TABLEAU_ACTIVATION_DAILY.csv as separate analytical sources later. They include descriptive attributes to work without Snowflake. The normalized DIM/FACT/BRIDGE files support the later Snowflake exercise.

## Metric rules
- TABLEAU_* files are derived conveniences. Do not union them with raw FACT files or count both.
- Stream daily volume is the sum of attempts completed that day. All generated stream attempts finish before 23:00 UTC. Segment runs start at 23:00; activation runs at 23:30. Daily snapshots are 23:59:59. No future observation is used for downstream processing.
- Failed stream attempts are atomic infrastructure failures: zero accepted and zero rejected records. A failed run with zero rejected records is intentional. Successful runs may have rejected records. This is why run success and record quality are separate KPIs.
- A retry follows a failed attempt and shares its obligation. At most one successful commit per obligation; volume never commits twice. Only first attempts can fail in this simulation. This is a simplification, not a claim about production retry behavior.
- Late success remains an SLA breach for that obligation. Daily SLA compliance is SUM(Daily_Obligations_Met)/SUM(Daily_Obligations_Due), never an average of stream percentages.
- Snapshot SLA_Status refers only to the latest obligation. Daily_SLA_Breach_Count includes earlier breaches even if later recovered. Health reflects the latest obligation/run, rather than permanently penalizing a recovered stream for all earlier failures.
- Warning means latest-run rejection ratio >1%, latest-run duration >50 minutes, or successful-refresh age greater than refresh interval, provided no Failed condition applies.
- Snapshot Last_Refresh_Time and duration refer to the latest observed attempt. When latest scheduled run is missing, Status is Not Started, health is Failed, and older observation fields carry forward.
- Processing success = Success attempts / (Success + Failed attempts). Missing attempts affect SLA, not the run denominator. There are no in-progress runs in these end-of-day snapshots.
- Use selected Snapshot_Time for freshness. NOW() would incorrectly age this fixed historical demo.
- Initial last success is a synthetic baseline four hours before the first reporting day. This is explicitly stored in DIM_DATA_STREAM and is not a hidden run.
- Segment population is last successful size, with Population_As_Of; failed segments retain stale populations. Do not sum populations over time. Segments may overlap.
- Segment runs fail when any required upstream stream has Failed health, or occasionally from their own evaluation error. Blocking_Data_Stream_ID shows one offending dependency. This describes the generator's mechanism, not inferred real-world causation.
- Activations depend on the same day's segment execution. A failed segment blocks delivery (zero attempted). Independent destination failures reject all attempted delivery records. Successful activation deliveries can have minor rejections. Delivered records never exceed the parent segment population.
- Source and owner labels are fictional generic categories. SYNTHETIC_INCIDENTS documents deliberately injected episodes; random incidental errors have blank Incident_ID.
- No unique person-level data is present. Records processed, segment population and activation records measure different things and must not be added together.

## Modeling guidance
DIM_DATA_STREAM to stream facts: one-to-many on Data_Stream_ID. DIM_SEGMENT and DIM_ACTIVATION to their facts: one-to-many. DIM_DATE to dated facts: one-to-many. Run to obligation: many-to-one; obligation to Successful_Run_ID is optional and at most one.
Bridge tables support dependency navigation, not physical joins for summing volumes. Joining multiple facts or bridge relationships can multiply rows. DAILY_OPERATIONS_SUMMARY is a separately aggregated reconciliation source; do not physically join its totals onto detailed facts and sum them.

## File inventory
'''
for name,rows in tables.items(): readme+=f'- {name}.csv — {len(rows):,} rows. {grains[name]}.\n'
(OUT/'README.md').write_text(readme,encoding='utf-8')
manifest={name:dict(rows=len(rows),sha256=hashlib.sha256((OUT/f'{name}.csv').read_bytes()).hexdigest()) for name,rows in tables.items()}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps({'period':[date(START),date(END)],'rows':{k:len(v) for k,v in tables.items()},'latest':summary[-1]},indent=2))
