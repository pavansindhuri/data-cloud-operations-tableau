import csv, json, hashlib, zipfile
from pathlib import Path
from datetime import datetime
from collections import defaultdict, Counter

root=Path(__file__).resolve().parent.parent
p=root/'outputs'/'data_cloud_step2'
data={f.stem:list(csv.DictReader(f.open(encoding='utf-8',newline=''))) for f in p.glob('*.csv')}
checks=[]
def check(label, condition):
    if not condition: raise AssertionError(label)
    checks.append(label)
def unique(name,keys):
    rows=data[name]; check(name+' unique grain',len(rows)==len({tuple(r[k] for k in keys) for r in rows}))
for n,k in {'DIM_DATE':['Date'],'DIM_DATA_STREAM':['Data_Stream_ID'],'DIM_SEGMENT':['Segment_ID'],'DIM_ACTIVATION':['Activation_ID'],'FACT_STREAM_RUN':['Run_ID'],'FACT_REFRESH_OBLIGATION':['Obligation_ID'],'FACT_STREAM_DAILY_SNAPSHOT':['Date','Data_Stream_ID'],'FACT_SEGMENT_RUN':['Segment_Run_ID'],'FACT_ACTIVATION_RUN':['Activation_Run_ID'],'BRIDGE_STREAM_SEGMENT':['Data_Stream_ID','Segment_ID'],'BRIDGE_SEGMENT_ACTIVATION':['Segment_ID','Activation_ID'],'TABLEAU_STREAM_DAILY':['Date','Data_Stream_ID'],'TABLEAU_SEGMENT_DAILY':['Date','Segment_ID'],'TABLEAU_ACTIVATION_DAILY':['Date','Activation_ID'],'DAILY_OPERATIONS_SUMMARY':['Date'],'SYNTHETIC_INCIDENTS':['Incident_ID'],'DATA_DICTIONARY':['Table_Name','Column_Name']}.items(): unique(n,k)
manifest=json.loads((p/'manifest.json').read_text())
check('CSV row counts and SHA256 match manifest',all(len(data[n])==v['rows'] and hashlib.sha256((p/(n+'.csv')).read_bytes()).hexdigest()==v['sha256'] for n,v in manifest.items()))
check('83 streams and exactly 20 critical',len(data['DIM_DATA_STREAM'])==83 and sum(int(r['Critical_Flag']) for r in data['DIM_DATA_STREAM'])==20)
check('180 dates, 30 segments and 45 activations',len(data['DIM_DATE'])==180 and len(data['DIM_SEGMENT'])==30 and len(data['DIM_ACTIVATION'])==45)
ids={key:{r[key] for r in data[t]} for key,t in [('Date','DIM_DATE'),('Data_Stream_ID','DIM_DATA_STREAM'),('Segment_ID','DIM_SEGMENT'),('Activation_ID','DIM_ACTIVATION'),('Obligation_ID','FACT_REFRESH_OBLIGATION'),('Segment_Run_ID','FACT_SEGMENT_RUN'),('Incident_ID','SYNTHETIC_INCIDENTS')]}
check('Foreign keys resolve',all(not r[k] or r[k] in ids[k] for rows in data.values() for r in rows for k in r if k in ids))
runs=data['FACT_STREAM_RUN']; obs=data['FACT_REFRESH_OBLIGATION']; snaps=data['FACT_STREAM_DAILY_SNAPSHOT']
runmap={r['Run_ID']:r for r in runs}; sm={r['Data_Stream_ID']:r for r in data['DIM_DATA_STREAM']}
byob=defaultdict(list); byday=defaultdict(list)
for r in runs: byob[r['Obligation_ID']].append(r); byday[(r['Date'],r['Data_Stream_ID'])].append(r)
check('All timestamps ordered and downstream stream cutoff respected',all(datetime.fromisoformat(r['Start_Time'])<=datetime.fromisoformat(r['End_Time']) and r['End_Time'][:10]==r['Date'] for n in ['FACT_STREAM_RUN','FACT_SEGMENT_RUN','FACT_ACTIVATION_RUN'] for r in data[n]) and all(r['End_Time']<r['Date']+' 23:00:00' for r in runs))
check('Run duration matches timestamps',all((datetime.fromisoformat(r['End_Time'])-datetime.fromisoformat(r['Start_Time'])).total_seconds()==int(r['Refresh_Duration_Minutes'])*60 for r in runs))
check('Nonnegative record components reconcile',all(int(r['Records_Attempted'])==int(r['Records_Processed'])+int(r['Records_Failed']) and min(int(r['Records_Processed']),int(r['Records_Failed']))>=0 for r in runs))
check('Record ratios correct including zero denominator',all((not r['Failure_Percentage'] if int(r['Records_Attempted'])==0 else abs(float(r['Failure_Percentage'])-int(r['Records_Failed'])/int(r['Records_Attempted']))<1e-8) for r in runs))
check('At most one successful commit per obligation',all(sum(r['Status']=='Success' for r in rr)<=1 for rr in byob.values()))
check('Retries follow failed first attempt',all(len(rr)==1 or (len(rr)==2 and rr[0]['Status']=='Failed' and rr[1]['Status']=='Success' and rr[1]['Start_Time']>rr[0]['End_Time']) for rr in byob.values()))
for o in obs:
    successful=[r for r in byob[o['Obligation_ID']] if r['Status']=='Success']
    met=any(r['End_Time']<=o['Expected_Refresh_Time'] for r in successful)
    assert (o['SLA_Status']=='Met')==met
    assert o['Successful_Run_ID']==(successful[0]['Run_ID'] if successful else '')
check('SLA evaluated from successful completion before deadline',True)
obday=defaultdict(list)
for o in obs: obday[(o['Date'],o['Data_Stream_ID'])].append(o)
last={sid:s['Initial_Last_Successful_Refresh'] for sid,s in sm.items()}
for snap in snaps:
    key=(snap['Date'],snap['Data_Stream_ID']); rr=byday[key]; oo=obday[key]; sid=key[1]
    for r in rr:
        if r['Status']=='Success': last[sid]=max(last[sid],r['End_Time'])
    assert snap['Last_Successful_Refresh']==last[sid]
    for metric in ['Records_Processed','Records_Failed']: assert int(snap[metric])==sum(int(r[metric]) for r in rr)
    assert int(snap['Daily_Run_Count'])==len(rr)
    assert int(snap['Daily_Obligations_Due'])==len(oo)
    assert int(snap['Daily_Obligations_Met'])==sum(o['SLA_Status']=='Met' for o in oo)
    assert int(snap['Daily_SLA_Breach_Count'])==sum(o['SLA_Status']=='Breached' for o in oo)
    latest=runmap[snap['Latest_Run_ID']]
    assert latest['Data_Stream_ID']==sid and latest['End_Time']<=snap['Snapshot_Time']
    age=(datetime.fromisoformat(snap['Snapshot_Time'])-datetime.fromisoformat(last[sid])).total_seconds()/3600
    assert abs(age-float(snap['Hours_Since_Last_Refresh']))<1e-6
    expected='Failed' if oo[-1]['SLA_Status']=='Breached' or latest['Status']=='Failed' else 'Warning' if float(latest['Failure_Percentage'] or 0)>.01 or int(latest['Refresh_Duration_Minutes'])>50 or age>int(sm[sid]['Refresh_Interval_Hours']) else 'Healthy'
    assert snap['Stream_Health']==expected
check('Daily metrics, current health, freshness and successful-refresh lineage reconcile',True)
sgmap={r['Segment_Run_ID']:r for r in data['FACT_SEGMENT_RUN']}
for a in data['FACT_ACTIVATION_RUN']:
    s=sgmap[a['Segment_Run_ID']]
    assert a['Segment_ID']==s['Segment_ID'] and a['Date']==s['Date'] and a['Start_Time']>s['End_Time']
    assert 0<=int(a['Activation_Records'])<=int(a['Activation_Records_Attempted'])<=int(s['Segment_Population'])
    assert int(a['Activation_Records_Attempted'])==int(a['Activation_Records'])+int(a['Activation_Records_Failed'])
    if s['Segment_Status']=='Failed': assert a['Activation_Status']=='Failed' and int(a['Activation_Records_Attempted'])==0
check('Activation lineage, timing, population limits and blocked delivery reconcile',True)
snapmap={(r['Date'],r['Data_Stream_ID']):r for r in snaps}
deps=defaultdict(set)
for b in data['BRIDGE_STREAM_SEGMENT']: deps[b['Segment_ID']].add(b['Data_Stream_ID'])
for s in data['FACT_SEGMENT_RUN']:
    if s['Blocking_Data_Stream_ID']:
        assert s['Blocking_Data_Stream_ID'] in deps[s['Segment_ID']]
        assert snapmap[(s['Date'],s['Blocking_Data_Stream_ID'])]['Stream_Health']=='Failed'
    assert s['Population_As_Of']<=s['End_Time']
check('Segment blocker references and population timestamps valid',True)
for n,dim,fact,k in [('TABLEAU_STREAM_DAILY','DIM_DATA_STREAM','FACT_STREAM_DAILY_SNAPSHOT','Data_Stream_ID'),('TABLEAU_SEGMENT_DAILY','DIM_SEGMENT','FACT_SEGMENT_RUN','Segment_ID'),('TABLEAU_ACTIVATION_DAILY','DIM_ACTIVATION','FACT_ACTIVATION_RUN','Activation_ID')]:
    dm={r[k]:r for r in data[dim]}
    check(n+' derived values match normalized sources',len(data[n])==len(data[fact]) and all(all(r[c]==v for c,v in f.items()) and all(r[c]==v for c,v in dm[f[k]].items()) for r,f in zip(data[n],data[fact])))
for r in data['DAILY_OPERATIONS_SUMMARY']:
    ss=[snapmap[(r['Date'],sid)] for sid in sm]
    assert sum(int(r[k+'_Streams']) for k in ['Healthy','Warning','Failed','Unknown'])==83
    assert sum(x['Stream_Health']=='Failed' for x in ss)==int(r['Failed_Streams'])
    assert sum(int(x['Records_Processed']) for x in ss)==int(r['Records_Processed'])
    assert int(r['Obligations_Due'])==173 and int(r['Obligations_Met'])+int(r['SLA_Breaches'])==173
check('Executive summary balances on all 180 dates',True)
check('Missing runs, retries, late successes and partial rejects are present',any(o['Breach_Reason']=='No Run Started' for o in obs) and any(len(rr)==2 for rr in byob.values()) and any(o['Breach_Reason']=='Late Completion' for o in obs) and any(int(r['Records_Failed'])>0 and r['Status']=='Success' for r in runs))
check('Daily entity coverage complete',all(Counter(r['Date'] for r in data[n])=={d['Date']:count for d in data['DIM_DATE']} for n,count in [('FACT_STREAM_DAILY_SNAPSHOT',83),('FACT_SEGMENT_RUN',30),('FACT_ACTIVATION_RUN',45)]))
report='# Dataset validation\n\nValidated saved CSV files. All checks below passed. This verifies generated-data consistency, not Tableau application rendering or publishing.\n\n'+''.join('- '+c+'\n' for c in checks)
report+='\n## Latest snapshot: 2026-09-14\n\n'+''.join(f'- {k}: {v}\n' for k,v in data['DAILY_OPERATIONS_SUMMARY'][-1].items())
(p/'VALIDATION_REPORT.md').write_text(report,encoding='utf-8')
zip_path=root/'outputs'/'Data_Cloud_Monitoring_Synthetic_Datasets.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(p.iterdir()): z.write(f,arcname='data_cloud_step2/'+f.name)
with zipfile.ZipFile(zip_path) as z: assert z.testzip() is None
print(json.dumps({'checks_passed':len(checks),'csv_files':len(data),'zip_bytes':zip_path.stat().st_size,'latest_health':{k:data['DAILY_OPERATIONS_SUMMARY'][-1][k] for k in ['Healthy_Streams','Warning_Streams','Failed_Streams']}}))
