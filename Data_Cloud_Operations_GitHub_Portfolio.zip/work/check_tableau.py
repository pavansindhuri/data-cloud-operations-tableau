from pathlib import Path
from lxml import etree as E
import zipfile,csv,io,re,json
p=Path(__file__).resolve().parent.parent/'outputs'
f=p/'Enterprise Data Cloud Operations.twbx'
with zipfile.ZipFile(f) as z:
    assert z.testzip() is None
    xml=z.read('Enterprise Data Cloud Operations.twb')
    root=E.fromstring(xml)
    assert len(root.findall('./dashboards/dashboard'))==4
    sheets={s.get('name') for s in root.findall('./worksheets/worksheet')}
    assert len(sheets)==34
    for ds in root.findall('./datasources/datasource'):
        con=ds.find('connection')
        if con is None: continue
        filename=con.get('directory')+'/'+con.get('filename')
        assert filename in z.namelist()
        records=list(csv.DictReader(io.StringIO(z.read(filename).decode('utf8'))))
        physical={c.get('name') for c in con.findall('relation/columns/column')}
        assert physical==set(records[0])
        latest=[r for r in records if r['Date']=='2026-09-14']
        if ds.get('name')=='Streams':
            assert len(latest)==83
            assert sum(int(r['Critical_Flag']) for r in latest)==20
            assert {h:sum(r['Stream_Health']==h for r in latest) for h in ['Healthy','Warning','Failed']}=={'Healthy':70,'Warning':6,'Failed':7}
    for w in root.findall('./worksheets/worksheet'):
        dep=w.find('./table/view/datasource-dependencies')
        fields={c.get('name') for c in dep.findall('column')}
        inst={c.get('name') for c in dep.findall('column-instance')}
        assert all(c.get('column') in fields for c in dep.findall('column-instance'))
        ds=dep.get('datasource')
        for ref in re.findall(r'\['+ds+r'\]\.\[([^\]]+)\]',E.tostring(w).decode()):
            assert '['+ref+']' in fields|inst,(w.get('name'),ref)
    for d in root.findall('./dashboards/dashboard'):
        for zone in d.findall('./zones/zone'):
            assert not zone.get('name') or zone.get('name') in sheets
    assert b'password=' not in xml and b'author-id=' not in xml
notes='''# Enterprise Data Cloud Operations — Tableau workbook

## Open
Open Enterprise Data Cloud Operations.twbx in Tableau Public 2026.2. This packaged workbook contains all four synthetic CSV sources; no Snowflake connection is required. Choose the 01 Executive Health dashboard tab if Tableau opens a worksheet first.

## Included
Four dashboards and 34 editable worksheets: Executive Health, Critical Streams, Segments and Activations, Operations Analysis. Controls include as-of date, trend window, source, stream scope, selected stream and selected population-trend segment. Each relevant source uses the same parameter definitions. Source/scope controls apply to stream analyses; they do not filter segment/activation data.

The default snapshot is 14 September 2026; data covers 19 March–14 September 2026. Keep the as-of date in that range. Default trend length is 30 days. Latest overall stream KPIs should show 83 total, 20 critical, 70 healthy, 6 warning and 7 failed. Source and scope selections can reduce these counts.

## Metric interpretation
Health is snapshot-based; trends count stream states by day. Failed runs and SLA breaches count events, including failures recovered later. Record totals are accepted/rejected processing volume, not unique customers. Segment population retains its last successful value on failure. Operations source contains run-level history enriched with the synthetic stream dimension.

Hover over marks for detail. Use the bottom dashboard tabs for navigation. Select a stream ID on Operations Analysis to inspect its failures and execution history. Select a segment ID on Segments and Activations to inspect one population trend.

## Verification and limitations
The workbook passes the bundled Tableau 2026.2 XML schema validator. ZIP integrity, packaged source schemas, worksheet field instances and dashboard worksheet references were checked. Default stream KPI counts reconcile to the generated dataset.

Application rendering and interactive behavior have NOT been verified. The computer-use screenshot helper failed with SetIsBorderRequired / No such interface supported, and the automatic launch produced a Windows tabpublic.exe Application Error dialog. This file is a build for review, not a visually verified final portfolio release. Inspect dashboard layout, date parsing, calculations, filters and labels in Tableau before publishing.

No Tableau Public upload has been performed. The package uses embedded CSV files rather than a prebuilt Hyper extract. Tableau Public may request extract creation during publishing. Publishing and account sign-in remain separate steps.

Advanced parameter/set actions, Dynamic Zone Visibility, Viz in Tooltip, phone layouts and public portfolio copy are not included in this build. They remain later enhancements after the workbook is verified in Tableau.
'''
(p/'Tableau_Workbook_README.md').write_text(notes,encoding='utf8')
print(json.dumps({'zip':'PASS','packaged_source_columns':'PASS','field_instance_references':'PASS','dashboard_references':'PASS','latest_stream_kpis':'PASS','rendering':'NOT VERIFIED'}))
