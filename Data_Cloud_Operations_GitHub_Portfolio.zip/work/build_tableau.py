from pathlib import Path
from lxml import etree as E
from copy import deepcopy
import csv, json, zipfile, uuid, shutil

ROOT=Path(__file__).resolve().parent.parent
DATA=ROOT/'outputs/data_cloud_step2'
BUILD=ROOT/'work/tableau_package'
(BUILD/'Data').mkdir(parents=True,exist_ok=True)
OUT=ROOT/'outputs'
TITLE='Enterprise Data Cloud Operations'
def sub(p,tag,text=None,**attrs):
    e=E.SubElement(p,tag,{k.replace('__','-'):str(v) for k,v in attrs.items()})
    if text is not None:e.text=str(text)
    return e
def ident(p):
    # Only window identifiers are enabled by WindowsPersistSimpleIdentifiers.
    # Worksheet/dashboard IDs require a separate feature flag in Tableau's loader.
    if p.tag=='window':sub(p,'simple-id',uuid='{'+str(uuid.uuid4()).upper()+'}')
def styles(p,rules):
    st=sub(p,'style')
    for elem,formats in rules.items():
        r=sub(st,'style-rule',element=elem)
        for attr,value in formats.items():sub(r,'format',attr=attr,value=value)
    return st
wb=E.Element('workbook',{'original-version':'18.1','source-build':'2026.2.1 (20262.26.0708.1337)','source-platform':'win','version':'18.1'},nsmap={'user':'http://www.tableausoftware.com/xml/user'})
manifest=sub(wb,'document-format-change-manifest');sub(manifest,'WindowsPersistSimpleIdentifiers')
sub(wb,'preferences'); sources=sub(wb,'datasources')
params=sub(sources,'datasource',name='Parameters',inline='true',hasconnection='false',version='18.1')
def param(name,caption,dtype,value,values=None):
    c=sub(params,'column',name=f'[{name}]',caption=caption,datatype=dtype,role='measure',type='quantitative' if dtype in ('integer','date') else 'nominal',param__domain__type='list' if values else 'any',value=value)
    sub(c,'calculation',formula=value,**{'class':'tableau'})
    if values:
        m=sub(c,'members')
        for v in values:sub(m,'member',value=v)
param('AsOf','As of','date','#2026-09-14#')
param('Days','Days','integer','30',['7','30','90','180'])
param('Source','Source','string','"All"',['"'+x+'"' for x in ['All','CRM','Commerce','Service','Loyalty','Web Events','Partner Files']])
param('Scope','Scope','string','"All streams"',['"All streams"','"Critical only"'])
param('SelectedStream','Stream','string','"DS003"',['"DS%03d"'%i for i in range(1,84)])
param('SelectedSegment','Segment','string','"SEG003"',['"SEG%03d"'%i for i in range(1,31)])

dictionary=list(csv.DictReader((DATA/'DATA_DICTIONARY.csv').open(encoding='utf8')))
type_map={(r['Table_Name'],r['Column_Name']):{'INTEGER':'integer','DECIMAL':'real','DATE':'date','TIMESTAMP_NTZ':'datetime','TEXT':'string'}[r['Recommended_Type']] for r in dictionary}
dim={r['Data_Stream_ID']:r for r in csv.DictReader((DATA/'DIM_DATA_STREAM.csv').open(encoding='utf8'))}
raw=list(csv.DictReader((DATA/'FACT_STREAM_RUN.csv').open(encoding='utf8')))
rr=[{**dim[r['Data_Stream_ID']],**r} for r in raw]
with (BUILD/'Data/OPERATIONS_RUNS.csv').open('w',encoding='utf8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rr[0]);w.writeheader();w.writerows(rr)
dsmeta={}
def datasource(name,file,caption):
    if file!='OPERATIONS_RUNS':shutil.copyfile(DATA/(file+'.csv'),BUILD/'Data'/(file+'.csv'))
    rows=list(csv.DictReader((BUILD/'Data'/(file+'.csv')).open(encoding='utf8')))
    d=sub(sources,'datasource',name=name,caption=caption,inline='true',version='18.1')
    con=sub(d,'connection',directory='Data',filename=file+'.csv',**{'class':'textscan'})
    rel=sub(con,'relation',name=file+'.csv',table='['+file+'#csv]',type='table')
    cols=sub(rel,'columns',character__set='UTF-8',header='yes',locale='en_US',separator=',')
    metadata=sub(con,'metadata-records')
    fields={}
    for i,k in enumerate(rows[0]):
        dtype=type_map.get((file,k),type_map.get(('FACT_STREAM_RUN',k),type_map.get(('DIM_DATA_STREAM',k),'string')))
        sub(cols,'column',name=k,datatype=dtype,ordinal=i)
        md=sub(metadata,'metadata-record',**{'class':'column'})
        for tag,val in [('remote-name',k),('remote-type',{'string':129,'integer':20,'real':5,'date':133,'datetime':135}[dtype]),('local-name','['+k+']'),('parent-name','['+file+'#csv]'),('remote-alias',k),('ordinal',i),('local-type',dtype),('aggregation','Sum' if dtype in ['integer','real'] else 'Year' if dtype in ['date','datetime'] else 'Count'),('contains-null','true')]:sub(md,tag,val)
        role='measure' if dtype in ('integer','real') else 'dimension'
        c=sub(d,'column',name='['+k+']',caption=k.replace('_',' '),datatype=dtype,role=role,type='quantitative' if role=='measure' else 'ordinal' if dtype in ('date','datetime') else 'nominal')
        if dtype in ('integer','real'):c.set('default-format','p0.0%' if 'Percentage' in k or 'Threshold' in k else 'n#,##0' if dtype=='integer' else 'n0.0')
        fields[k]=c
    dsmeta[name]={'node':d,'fields':fields,'caption':caption,'rows':rows}
    return name
S=datasource('Streams','TABLEAU_STREAM_DAILY','Stream daily health')
G=datasource('Segments','TABLEAU_SEGMENT_DAILY','Segment daily monitoring')
A=datasource('Activations','TABLEAU_ACTIVATION_DAILY','Activation daily monitoring')
R=datasource('Runs','OPERATIONS_RUNS','Stream execution history')
def calc(ds,k,formula,dtype='real',role='measure',numfmt=None):
    c=sub(dsmeta[ds]['node'],'column',name='['+k+']',caption=k.replace('_',' '),datatype=dtype,role=role,type='quantitative' if role=='measure' else 'nominal')
    if numfmt:c.set('default-format',{'p1%':'p0.0%','p2%':'p0.00%','n1':'n0.0','n0':'n#,##0'}.get(numfmt,numfmt))
    sub(c,'calculation',formula=formula,**{'class':'tableau'});dsmeta[ds]['fields'][k]=c
for ds in dsmeta:
    calc(ds,'Selected_Date','[Date] = [Parameters].[AsOf]','boolean','dimension')
    calc(ds,'In_Window',"[Date] <= [Parameters].[AsOf] AND [Date] > DATEADD('day', -[Parameters].[Days], [Parameters].[AsOf])",'boolean','dimension')
    calc(ds,'Dataset_Last_Date','{ FIXED : MAX([Date]) }','date','dimension')
    if ds in (S,R):
        calc(ds,'Source_Filter','[Parameters].[Source] = "All" OR [Source_System] = [Parameters].[Source]','boolean','dimension')
        calc(ds,'Scope_Filter','[Parameters].[Scope] = "All streams" OR [Critical_Flag] = 1','boolean','dimension')
        calc(ds,'Critical_Only','[Critical_Flag] = 1','boolean','dimension')
        calc(ds,'Selected_Stream','[Data_Stream_ID] = [Parameters].[SelectedStream]','boolean','dimension')
calc(S,'Total_Streams','COUNTD([Data_Stream_ID])',numfmt='n0')
calc(S,'Critical_Streams','COUNTD(IF [Critical_Flag] = 1 THEN [Data_Stream_ID] END)',numfmt='n0')
for h in ['Healthy','Warning','Failed']:
    calc(S,h+'_Streams',f'COUNTD(IF [Stream_Health] = "{h}" THEN [Data_Stream_ID] END)',numfmt='n0')
calc(S,'SLA_Compliance','SUM([Daily_Obligations_Met]) / SUM([Daily_Obligations_Due])',numfmt='p1%')
calc(S,'Success_Rate','SUM([Daily_Successful_Runs]) / SUM([Daily_Run_Count])',numfmt='p1%')
calc(S,'Record_Failure_Rate','SUM([Records_Failed]) / (SUM([Records_Processed]) + SUM([Records_Failed]))',numfmt='p2%')
calc(S,'Daily_Healthy','IF [Stream_Health] = "Healthy" THEN 1 ELSE 0 END','integer')
calc(S,'Refresh_Age','MAX([Hours_Since_Last_Refresh])',numfmt='n1')
calc(S,'Duration','AVG([Refresh_Duration_Minutes])',numfmt='n1')
calc(S,'Rejection_Hundredths','INT(ROUND([Failure_Percentage] * 10000, 0))','integer')
calc(S,'Rejection_Display','IF ISNULL([Rejection_Hundredths]) THEN "n/a" ELSE STR(INT([Rejection_Hundredths] / 100)) + "." + RIGHT("00" + STR([Rejection_Hundredths] % 100), 2) + "%" END','string','dimension')
calc(S,'Critical_Detail','STR([Records_Processed]) + " accepted / " + STR([Records_Failed]) + " rejected | " + [Rejection_Display] + " | " + STR([Refresh_Duration_Minutes]) + " min"','string','dimension')
calc(S,'Refresh_Display',"STR([Last_Successful_Refresh])",'string','dimension')
calc(S,'Deadline_Display',"STR([Expected_Refresh_Time])",'string','dimension')
calc(S,'Attention_Order','IF [Stream_Health] = "Failed" THEN 1 ELSEIF [Stream_Health] = "Warning" THEN 2 ELSE 3 END','integer','dimension')
calc(G,'Segment_Success','SUM(IF [Segment_Status] = "Success" THEN 1 ELSE 0 END) / COUNT([Segment_Run_ID])',numfmt='p1%')
calc(G,'Segment_Count','COUNTD([Segment_ID])',numfmt='n0')
calc(G,'Segment_Failed','COUNTD(IF [Segment_Status] = "Failed" THEN [Segment_ID] END)',numfmt='n0')
calc(G,'Segment_Run_Count','COUNT([Segment_Run_ID])',numfmt='n0')
calc(G,'Selected_Segment','[Segment_ID] = [Parameters].[SelectedSegment]','boolean','dimension')
calc(G,'Segment_Exception','[Segment_Status] = "Failed"','boolean','dimension')
calc(A,'Activation_Success','SUM(IF [Activation_Status] = "Success" THEN 1 ELSE 0 END) / COUNT([Activation_Run_ID])',numfmt='p1%')
calc(A,'Activation_Count','COUNTD([Activation_ID])',numfmt='n0')
calc(A,'Activation_Run_Count','COUNT([Activation_Run_ID])',numfmt='n0')
calc(R,'Failed_Run_Count','SUM(IF [Status] = "Failed" THEN 1 ELSE 0 END)',numfmt='n0')
calc(R,'Failed_Only','[Status] = "Failed"','boolean','dimension')
calc(R,'Average_Success_Duration','AVG(IF [Status] = "Success" THEN [Refresh_Duration_Minutes] END)',numfmt='n1')
calc(R,'Record_Reject_Rate','SUM([Records_Failed]) / (SUM([Records_Processed]) + SUM([Records_Failed]))',numfmt='p2%')

# Semantic palette, with explicit text labels alongside every status encoding.
for ds,field in [(S,'Stream_Health'),(S,'Status'),(G,'Segment_Status'),(A,'Activation_Status'),(R,'Status')]:
    node=dsmeta[ds]['node']; st=node.find('style')
    if st is None:st=sub(node,'style')
    rule=st.find("style-rule[@element='mark']")
    if rule is None:rule=sub(st,'style-rule',element='mark')
    enc=sub(rule,'encoding',attr='color',field=f'[none:{field}:nk]',type='palette')
    for label,color in [('Healthy','#16856b'),('Success','#16856b'),('Warning','#c88916'),('Failed','#cc4056'),('Unknown','#8b95a5'),('Not Started','#cc4056')]:
        m=sub(enc,'map',to=color);sub(m,'bucket','"'+label+'"')

worksheets=sub(wb,'worksheets'); sheetinfo={}
def worksheet(name,ds,kind='Bar',rows=None,cols=None,text=None,color=None,filters=None,tooltip=None,kpi=False):
    rows=rows or [];cols=cols or [];text=text or [];filters=filters or []
    w=sub(worksheets,'worksheet',name=name)
    display_title='Avg. refresh minutes' if name=='Successful refresh minutes' else name
    layout=sub(w,'layout-options'); title=sub(sub(layout,'title'),'formatted-text');sub(title,'run',display_title,fontname='Arial',fontsize='12',bold='true',fontcolor='#172b4d')
    t=sub(w,'table');v=sub(t,'view');dss=sub(v,'datasources');sub(dss,'datasource',name=ds,caption=dsmeta[ds]['caption']);sub(dss,'datasource',name='Parameters')
    dep=sub(v,'datasource-dependencies',datasource=ds)
    for c in dsmeta[ds]['fields'].values():dep.append(deepcopy(c))
    pdep=sub(v,'datasource-dependencies',datasource='Parameters')
    for c in params:pdep.append(deepcopy(c))
    used={}
    def ref(spec):
        if isinstance(spec,str):spec=(spec,'None','nominal')
        field,derivation,typ=spec
        pref={'None':'none','Sum':'sum','Avg':'avg','CountD':'ctd','Count':'cnt','User':'usr','Min':'min','Max':'max','Attribute':'attr'}[derivation]
        short=f'[{pref}:{field}:{"qk" if typ=="quantitative" else "ok" if typ=="ordinal" else "nk"}]'
        if short not in used:
            ci=sub(dep,'column-instance',column='['+field+']',derivation=derivation,name=short,pivot='key',type=typ);used[short]=ci
        return '['+ds+'].'+short
    if ds in (S,R):filters=['Source_Filter','Scope_Filter']+filters
    for field in filters:
        full=ref(field);f=sub(v,'filter',column=full,**{'class':'categorical'});sub(f,'groupfilter',function='member',level=full.split('].',1)[1],member='true')
    rrefs=[ref(x) for x in rows];crefs=[ref(x) for x in cols];trefs=[ref(x) for x in text];colorref=ref(color) if color else None
    # Tooltip-only fields must be measures. Tableau cannot auto-convert the
    # explicitly generated unaggregated instances to ATTR during workbook load.
    tiprefs=[]
    for label,spec in tooltip or []:
        if isinstance(spec,str):spec=(spec,'Attribute','nominal')
        elif spec[1]=='None':spec=(spec[0],'Min',spec[2])
        tiprefs.append((label,ref(spec)))
    # Leave categorical order at Tableau's default. computed-sort requires a
    # feature-specific document manifest absent from this portable workbook.
    sub(v,'aggregation',value='true')
    styles(t,{'table':{'background-color':'#ffffff','font-family':'Arial','font-size':'10'},'worksheet':{'display-field-labels':'true'},'gridline':{'line-visibility':'off'},'zeroline':{'line-visibility':'off'},'table-div':{'line-visibility':'off'},'cell':{'height':'27','text-align':'center' if kpi else 'left'},'label':{'font-family':'Arial','font-size':'9'},'header':{'font-family':'Arial','font-size':'9'}})
    if name=='Critical stream register':
        header=t.find("style/style-rule[@element='header']")
        for field,width in [('Data_Stream_Name',205),('Stream_Health',90),('Priority',55),('SLA_Status',90)]:
            sub(header,'format',attr='width',field=ref(field),value=str(width))
    if name=='Activation destinations':
        sub(t.find("style/style-rule[@element='header']"),'format',attr='width',field=ref('Activation_Destination'),value='155')
    if name=='Segment exception detail':
        header=t.find("style/style-rule[@element='header']")
        for field,width in [('Segment_Name',275),('Segment_Status',105),('Error_Type',220)]:
            sub(header,'format',attr='width',field=ref(field),value=str(width))
    if name in ('Failure error categories','Selected stream execution log'):
        header=t.find("style/style-rule[@element='header']")
        widths=[('Error_Type',165)] if name=='Failure error categories' else [('Date',110),('Run_ID',125),('Status',90),('Error_Type',220)]
        for field,width in widths:
            sub(header,'format',attr='width',field=ref(field),value=str(width))
    panes=sub(t,'panes');pane=sub(panes,'pane',selection__relaxation__option='selection-relaxation-allow')
    sub(sub(pane,'view'),'breakdown',value='auto');sub(pane,'mark',**{'class':kind})
    enc=sub(pane,'encodings')
    for x in trefs:sub(enc,'text',column=x)
    if colorref:sub(enc,'color',column=colorref)
    for label,x in tiprefs:sub(enc,'tooltip',column=x)
    ft=sub(sub(pane,'customized-tooltip',show__buttons='false'),'formatted-text')
    sub(ft,'run',name+'\n',bold='true',fontcolor='#172b4d')
    for label,x in tiprefs:sub(ft,'run',label+': <'+x+'>\n')
    if not tiprefs:
        for x in rrefs+crefs+trefs:sub(ft,'run','<'+x+'>\n')
    sub(ft,'run','Synthetic portfolio data • UTC',fontsize='9',fontcolor='#69788b')
    if kpi:
        ft=sub(sub(pane,'customized-label'),'formatted-text')
        sub(ft,'run','<'+trefs[0]+'>',fontname='Arial',fontsize='24',bold='true',fontcolor='#172b4d',fontalignment='1')
    if name in ('Segment exception detail','Selected stream execution log'):
        prefix='Last successful population: ' if name=='Segment exception detail' else 'Accepted records: '
        ft=sub(sub(pane,'customized-label'),'formatted-text')
        sub(ft,'run',prefix+'<'+trefs[0]+'>',fontname='Arial',fontsize='9',fontcolor='#172b4d')
    pst=styles(pane,{'mark':{'mark-color':'#337aa0','mark-labels-show':'true' if text or kind=='Text' or kpi else 'false','size':'0.6'},'datalabel':{'font-family':'Arial','font-size':'24' if kpi else '9','color':'#172b4d'},'cell':{'text-align':'center' if kpi else 'left'}})
    if colorref and color in ('Stream_Health','Status','Segment_Status','Activation_Status'):
        rule=pst.find("style-rule[@element='mark']")
        enc=sub(rule,'encoding',attr='color',field=colorref.split('].',1)[1],type='palette')
        for label,hexcolor in [('Healthy','#16856b'),('Success','#16856b'),('Warning','#c88916'),('Failed','#cc4056'),('Unknown','#8b95a5'),('Not Started','#cc4056')]:
            sub(sub(enc,'map',to=hexcolor),'bucket','"'+label+'"')
    sub(t,'rows',' / '.join(rrefs));sub(t,'cols',' / '.join(crefs));ident(w)
    sheetinfo[name]={'ds':ds,'kpi':kpi};return name
U=lambda f:(f,'User','quantitative')
SUM=lambda f:(f,'Sum','quantitative')
COUNT=lambda f:(f,'CountD','quantitative')
DATE=('Date','None','quantitative')
snap=['Selected_Date']; trend=['In_Window']
for name,field in [('Total streams','Total_Streams'),('Critical streams','Critical_Streams'),('Healthy','Healthy_Streams'),('Warning','Warning_Streams'),('Failed','Failed_Streams'),('SLA compliance','SLA_Compliance'),('Run success','Success_Rate')]:worksheet(name,S,'Text',text=[U(field)],filters=snap,kpi=True)
worksheet('Records accepted',S,'Text',text=[SUM('Records_Processed')],filters=snap,kpi=True)
worksheet('Health through time',S,'Line',rows=[COUNT('Data_Stream_ID')],cols=[DATE],color='Stream_Health',filters=trend,tooltip=[('Date',DATE),('Health','Stream_Health'),('Streams',COUNT('Data_Stream_ID'))])
worksheet('Daily failed runs',S,'Line',rows=[SUM('Daily_Failed_Runs')],cols=[DATE],filters=trend)
worksheet('Source system health',S,'Bar',rows=['Source_System'],cols=[COUNT('Data_Stream_ID')],color='Stream_Health',filters=snap)
worksheet('Daily SLA compliance',S,'Line',rows=[U('SLA_Compliance')],cols=[DATE],filters=trend)
worksheet('Critical stream register',S,'Text',rows=['Data_Stream_Name','Stream_Health','Priority','SLA_Status'],text=['Critical_Detail'],filters=snap+['Critical_Only'],tooltip=[('Stream ID','Data_Stream_ID'),('Owner','Owner_Support_Team'),('Last successful refresh (UTC)',('Last_Successful_Refresh','Max','ordinal')),('Expected refresh (UTC)',('Expected_Refresh_Time','Max','ordinal')),('Accepted',SUM('Records_Processed')),('Rejected',SUM('Records_Failed')),('Daily rejection',U('Record_Failure_Rate')),('Latest duration (min)',('Refresh_Duration_Minutes','Max','quantitative')),('Hours since success',U('Refresh_Age'))])
worksheet('Critical failed',S,'Text',text=[U('Failed_Streams')],filters=snap+['Critical_Only'],kpi=True)
worksheet('Critical SLA compliance',S,'Text',text=[U('SLA_Compliance')],filters=snap+['Critical_Only'],kpi=True)
worksheet('Critical accepted',S,'Text',text=[SUM('Records_Processed')],filters=snap+['Critical_Only'],kpi=True)
worksheet('Critical SLA breaches over time',S,'Line',rows=[SUM('Daily_SLA_Breach_Count')],cols=[DATE],filters=trend+['Critical_Only'])
for name,ds,field in [('Segments',G,'Segment_Count'),('Segment success',G,'Segment_Success'),('Activations',A,'Activation_Count'),('Activation success',A,'Activation_Success')]:worksheet(name,ds,'Text',text=[U(field)],filters=snap,kpi=True)
worksheet('Segment health',G,'Bar',rows=['Segment_Status'],cols=[U('Segment_Count')],color='Segment_Status',filters=snap)
worksheet('Segment population history',G,'Line',rows=[SUM('Segment_Population')],cols=[DATE],color='Segment_Name',filters=trend+['Selected_Segment'],tooltip=[('Segment','Segment_Name'),('Date',DATE),('Last successful population',SUM('Segment_Population'))])
worksheet('Activation destinations',A,'Bar',rows=['Activation_Destination'],cols=[U('Activation_Count')],text=['Activation_Status'],color='Activation_Status',filters=snap,tooltip=[('Destination','Activation_Destination'),('Status','Activation_Status'),('Activations',U('Activation_Count'))])
worksheet('Activation delivered volume',A,'Line',rows=[SUM('Activation_Records')],cols=[DATE],filters=trend)
worksheet('Segment exception detail',G,'Text',rows=['Segment_Name','Segment_Status','Error_Type'],text=[SUM('Segment_Population')],filters=snap+['Segment_Exception'],tooltip=[('Segment','Segment_Name'),('Status','Segment_Status'),('Last successful population',SUM('Segment_Population')),('Population as of',('Population_As_Of','Max','ordinal')),('Blocking stream','Blocking_Data_Stream_ID')])
worksheet('Failed attempts in window',R,'Text',text=[U('Failed_Run_Count')],filters=trend,kpi=True)
worksheet('Successful refresh minutes',R,'Text',text=[U('Average_Success_Duration')],filters=trend,kpi=True)
worksheet('Record rejection rate',R,'Text',text=[U('Record_Reject_Rate')],filters=trend,kpi=True)
worksheet('SLA breaches in window',S,'Text',text=[SUM('Daily_SLA_Breach_Count')],filters=trend,kpi=True)
worksheet('Failure error categories',R,'Bar',rows=['Error_Type'],cols=[U('Failed_Run_Count')],filters=trend+['Failed_Only'])
worksheet('Failed attempts by source',R,'Bar',rows=['Source_System'],cols=[U('Failed_Run_Count')],filters=trend)
worksheet('Selected stream failures',R,'Line',rows=[U('Failed_Run_Count')],cols=[DATE],filters=trend+['Selected_Stream'])
worksheet('Selected stream execution log',R,'Text',rows=['Date','Run_ID','Status','Error_Type'],text=[SUM('Records_Processed')],color='Status',filters=trend+['Selected_Stream'],tooltip=[('Start',('Start_Time','Min','ordinal')),('End',('End_Time','Max','ordinal')),('Accepted',SUM('Records_Processed')),('Rejected',SUM('Records_Failed')),('Duration minutes',SUM('Refresh_Duration_Minutes')),('Incident','Incident_ID')])

dashboards=sub(wb,'dashboards');dashnames=[]
def dash(name,title,subtitle,controls,placements,height=800):
    dashnames.append(name);d=sub(dashboards,'dashboard',name=name)
    styles(d,{'table':{'background-color':'#eef2f6'}})
    sub(d,'size',maxheight=str(height),maxwidth='1000',minheight=str(height),minwidth='1000',sizing__mode='fixed')
    dss=sub(d,'datasources');sub(dss,'datasource',name='Parameters')
    for ds in dsmeta:sub(dss,'datasource',name=ds,caption=dsmeta[ds]['caption'])
    dep=sub(d,'datasource-dependencies',datasource='Parameters')
    for c in params:dep.append(deepcopy(c))
    zones=sub(d,'zones'); zid=0
    def zone(x,y,w,h,**attrs):
        nonlocal zid
        zid+=1
        return sub(zones,'zone',id=zid,x=round(x/1440*100000),y=round(y/1000*100000),w=round(w/1440*100000),h=round(h/1000*100000),**attrs)
    def zs(z,bg,pad=8):
        s=sub(z,'zone-style')
        for k,v in [('background-color',bg),('border-style','none'),('padding',str(pad))]:sub(s,'format',attr=k,value=v)
    z=zone(0,0,1440,94,type__v2='text');ft=sub(z,'formatted-text');sub(ft,'run',title+'\n',fontname='Arial',fontsize='19',bold='true',fontcolor='#ffffff');sub(ft,'run',subtitle,fontname='Arial',fontsize='9',fontcolor='#bed3e5');zs(z,'#142b45',10)
    z=zone(20,95,1400,30,type__v2='text');ft=sub(z,'formatted-text');sub(ft,'run','SYNTHETIC DEMO  |  UTC  |  As of <[Parameters].[AsOf]>  |  Trend: <[Parameters].[Days]> days  |  Healthy • Warning • Failed',fontname='Arial',fontsize='10',fontcolor='#52677f');zs(z,'#eef2f6',4)
    width=1360/len(controls)
    for i,k in enumerate(controls):
        z=zone(20+i*(width+4),132,width,54,type__v2='paramctrl',mode='compact',param='[Parameters].['+k+']');zs(z,'#ffffff',6)
    for sheet,x,y,w,h in placements:
        z=zone(x,y,w,h,name=sheet,show__title='true');zs(z,'#ffffff',6)
    z=zone(20,958,1400,30,type__v2='text');ft=sub(z,'formatted-text');sub(ft,'run','Use the dashboard tabs below to navigate. Historical demonstration: 19 Mar–14 Sep 2026. No company or client data.',fontname='Arial',fontsize='9',fontcolor='#52677f');zs(z,'#eef2f6',3)
    ident(d)
def kpis(names):return [(n,20+i*350,200,338,104) for i,n in enumerate(names)]
dash('01 Executive Health','Enterprise Data Cloud | Executive Health','Operational reliability, freshness and exceptions across the monitored stream estate.',['AsOf','Days','Source','Scope'],kpis(['Total streams','Critical streams','Healthy','Failed'])+[(n,20+i*350,314,338,104) for i,n in enumerate(['Warning','SLA compliance','Run success','Records accepted'])]+[('Health through time',20,430,690,248),('Source system health',724,430,696,248),('Daily failed runs',20,690,690,254),('Daily SLA compliance',724,690,696,254)])
dash('02 Critical Streams','Enterprise Data Cloud | Critical Streams','Inspect health and SLA status across 20 critical streams. Hover over row metrics for refresh timestamps and owner.',['AsOf','Days','Source'],kpis(['Critical streams','Critical failed','Critical SLA compliance','Critical accepted'])+[('Critical stream register',20,320,1400,480),('Critical SLA breaches over time',20,814,1400,130)],height=1100)
dash('03 Segments and Activations','Enterprise Data Cloud | Segments & Activations','Audience readiness and delivery performance. Populations can overlap; they are not unique customer totals.',['AsOf','Days','SelectedSegment'],kpis(['Segments','Segment success','Activations','Activation success'])+[('Segment health',20,320,450,180),('Activation destinations',484,320,936,180),('Segment population history',20,512,690,180),('Activation delivered volume',724,512,696,180),('Segment exception detail',20,704,1400,240)],height=1100)
dash('04 Operations Analysis','Enterprise Data Cloud | Operations Analysis','KPIs cover source/scope and date window. Stream selects only the failure trend and execution log below.',['AsOf','Days','Source','Scope','SelectedStream'],kpis(['Failed attempts in window','SLA breaches in window','Successful refresh minutes','Record rejection rate'])+[('Failure error categories',20,320,690,210),('Failed attempts by source',724,320,696,210),('Selected stream failures',20,542,1400,180),('Selected stream execution log',20,734,1400,210)],height=1100)
windows=sub(wb,'windows',source__height='30')
detail_sheets={'Critical stream register','Segment exception detail','Selected stream execution log'}
for name in sheetinfo:
    win=sub(windows,'window',name=name,maximized='true',**{'class':'worksheet'})
    vp=sub(sub(win,'viewpoints'),'viewpoint',name=name);sub(vp,'zoom',type='fit-width' if name in detail_sheets else 'entire-view');sub(win,'active',id='0');ident(win)
for name in dashnames:
    win=sub(windows,'window',name=name,maximized='true',**{'class':'dashboard'})
    vp=sub(win,'viewpoints')
    for z in dashboards.find(f"dashboard[@name='{name}']/zones"):
        if z.get('name') in sheetinfo:sub(sub(vp,'viewpoint',name=z.get('name')),'zoom',type='fit-width' if z.get('name') in detail_sheets else 'entire-view')
    sub(win,'active',id='0');ident(win)
# Open to the executive dashboard before the supporting worksheet windows.
for name in reversed(dashnames):
    node=windows.find(f"window[@name='{name}']");windows.remove(node);windows.insert(0,node)
twb=BUILD/(TITLE+'.twb');E.ElementTree(wb).write(str(twb),encoding='utf-8',xml_declaration=True,pretty_print=True)
pkg=OUT/(TITLE+'.twbx')
with zipfile.ZipFile(pkg,'w',zipfile.ZIP_DEFLATED) as z:
    z.write(twb,twb.name)
    for f in (BUILD/'Data').glob('*.csv'):z.write(f,'Data/'+f.name)
with zipfile.ZipFile(pkg) as z:assert z.testzip() is None
print(json.dumps({'workbook':str(pkg),'worksheets':len(sheetinfo),'dashboards':dashnames,'bytes':pkg.stat().st_size}))
